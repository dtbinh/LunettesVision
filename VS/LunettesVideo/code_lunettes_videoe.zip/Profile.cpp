#include "Profile.h"

Profile::Profile(void)
{
}

Profile::~Profile(void)
{
}