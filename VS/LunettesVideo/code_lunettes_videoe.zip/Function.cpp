#include "Function.h"

Function::Function(void)
{
}

Function::~Function(void)
{
}

float Function::getX(float x) {
	return x;
}

float Function::getY(float y) {
	return y;
}

void Function::setSize(float x, float y) {
	width = x;
	height = y;
}